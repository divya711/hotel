<html>
<head>
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="link.php">
</head>
<body bgcolor="#fff2e5">

<?php
	include "header.php";
?>
<section class="section-padding-bottom">
		<div class="container">
			<div class="row">
				<div class="tm-section-header section-margin-top">
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-4 col-md-6 col-sm-6"><h2 class="tm-section-title">HOME</h2></div>
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>	
				</div>				
			</div>
	<br>
    	<div class="row">

	<table>
	<tr>
		<td>&nbsp;</td>
		<td><font color="#7c0000"><b><i></i></b></font><center>
		  <font color="#7c0000"><b><i>HOTEL IN AHMEDABAD:HOTEL HOLIDAY
		</i></b></font>
		</center></td>
	</tr>
	<tr>
		<td><a href=h1.php target=_blank><img src="image/273-2-zoom-1-aminta-grand-hotel-sorrento-lounge.jpg"width=144 height=166></a></td>
		<td><font color=chocolate>		
						Hotel HOLIDAY,among the premier
		business hotel in
						Ahmedabad the economic capital of
		gujrat is 			
						characterised by the traditionally
		hospitality located
						in the heart of the city.The ideal
		choice amongs hotels
						in Ahmedabad for businessman and
		tourist.</font></td>
		<td><a href=h2.php target=_blank><img src="image/image2.jpg" width=125 height=150></a></td>
	</tr>
	<tr>
		<td><font color="#7c0000">Entry</font></td>
		<td></td>
		<td><font color="#7c0000">Reception</font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><font color=darkpink>
					The HOLIDAY offers facilities that no 
		other Ahmedabad hotels
					offer.Each room is elegantly well
		appointed and equipped
					with complete amenities including
		aircondition fully stock
					minibars,directIDD telephone,TV
		with 24 hour satelight
					entertainment and news.Upscale
		bathroom with hair dryers
					and cosmetic mirrors,seperate
		hanging closets.</font></td>
		<td></td>
	</tr>
	</table>
		<br><br>
	<table>
		<tr>
			<td><a href=h3.php target=_blank><img src="image/pic5.jpg" width=125 height=150></a></td>
			<td><font color=chocolate>
			The only one Ahmedabad hotels having all facilities a business center,beauty parlor,health club,gym,saloon,
			boutique,internet cafe,pastry shop,travel desk and money exchange the HOLIDAY hotels given you full value
			for money.</font></td>
			<td><a href=h4.php target=_blank><img src="image/hrooms.jpg" width=125 height=150></a></td>
		</tr>
		<tr>
			<td><font color="#7c0000">Main hall</font></td>
		<td></td>
			<td><font color="#7c0000">Lobby</font></td>
		</tr>
		<td></td>
		<td><font color="darkpink">
		Hotel HOLIDAY takes pride in being a host to a number of celebrities,including bollywood and telewood starts,
		cricketers,political leaders as well as corporate borons and also being the most prefered in Ahmedabad.By the NRIs.
		<td></td>
        
		</tr>
	</table>
    </font>
    </div>
    </div>
    </section>
    <?php
	include "footer.php";
?>
</body>
</html>
		 



